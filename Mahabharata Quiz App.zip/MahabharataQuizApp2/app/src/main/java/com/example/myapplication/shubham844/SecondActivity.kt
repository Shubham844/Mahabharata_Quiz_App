package com.example.myapplication.shubham844

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class SecondActivity : AppCompatActivity() {

    private var currentQuestion = 0
    val questions=0

    private var questionList: ArrayList<QuestionData>? = null

    //initialization
    lateinit var textView2: TextView
    lateinit var textView3: TextView
    lateinit var btn2: Button
    lateinit var btn3: Button
    lateinit var btn4: Button
    lateinit var btn5: Button
    lateinit var btn6: Button
    lateinit var progressBar: ProgressBar
    lateinit var btn7: Button

    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        textView2 = findViewById(R.id.textView2)
        textView3 = findViewById(R.id.textView3)
        btn2 = findViewById(R.id.btn2)
        btn3 = findViewById(R.id.btn3)
        btn4 = findViewById(R.id.btn4)
        btn5 = findViewById(R.id.btn5)
        btn6 = findViewById(R.id.btn6)
        btn7 = findViewById(R.id.btn7)
        progressBar = findViewById(R.id.progressBar)


        setData.getQuestion()

        questionList = setData.getQuestion()
        var que = questionList!![0]
        textView3.text = que.question
        btn2.text = que.option_one
        btn3.text = que.option_two
        btn4.text = que.option_three
        btn5.text = que.option_four

        progressBar.progress = 1
        progressBar.max = questionList!!.size


//for prev button

        btn7.setOnClickListener {
            if (currentQuestion > 0) {
                currentQuestion--
                updateQuestion()
            }
        }

//for next button

        btn6.setOnClickListener {
            if(currentQuestion<questions-1){
                currentQuestion++
                updateQuestion()
            }
        }
 updateQuestion()

    }




    private fun updateQuestion() {
        val question = questions[currentQuestion].question
        textView3.text = question.toString()

    }
}



