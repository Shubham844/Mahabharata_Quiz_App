package com.example.myapplication.shubham844

object setData {


    //questions

    fun getQuestion():ArrayList<QuestionData>{
        var que:ArrayList<QuestionData> = arrayListOf()


        var q1=QuestionData(
            "In which yuga did the Mahabharata happen ?",
            1,"Treta Yuga","Dwapara Yuga","Satya Yuga","None of These",2
        )
        que.add(q1)


        var q2=QuestionData(
            "Who is the father of Bhishma Pitamah (Devavrata) ?",2,"King Pratipa",
            "King Kuru","King Shantanu","King Jahnu",3
        )
        que.add(q2)


        var q3=QuestionData(
            "Pandu and Dhritarashtra are the sons of ?",3,"Shantanu and Satyavathi",
            "Kuru and Sukadha","Bhishma and Ambika","Vichitravirya and Ambika",1
        )
        que.add(q3)


        var q4=QuestionData(
            "Who was Bhishma Pitamah's mother ?",4,"Laxmi","Satyavathi","Saraswati",
            "Ganga",4
        )
        que.add(q4)


        var q5=QuestionData(
            "Who gave Bhishma the boon that he would die only when he wished ?",5,"Dronacharya","Ganga",
            "Shri Krishna","Shantanu",4
        )
        que.add(q5)


        var q6=QuestionData(
            "Who were the two wives of Pandu ?",6,"Kunti and Madri","Amba and Karuna",
            "Uttara and Draupadi","Ambalika and Amba",1
        )
        que.add(q6)


        var q7=QuestionData(
            "Who was the wife of Dhritarashtra ?",7,"Dushala","Gandhari","Kunti",
            "Ambika",2
        )
        que.add(q7)


        var q8=QuestionData(
            "Name the rishi who cursed Pandu ?",8,"Rishi Vyasa","Rishi Vasishtha",
            "Rishi Kindam","Rishi Sage",3
        )
        que.add(q8)


        var q9=QuestionData(
            "What was the name of Gandhari's only daughter ?",9,"Ambi","Dushala","Ulupi",
            "None of These",2
        )
        que.add(q9)


        var q10=QuestionData(
            "At the time of his birth,in the voice of which animal did Duryodhana cry ?",10,"Dog","Jackal",
            "Cat","Lion",2
        )
        que.add(q10)

        var q11=QuestionData(
            "How many sons did Pandu have ?",11,"3","4","5","6",3
        )
        que.add(q11)

        var q12=QuestionData(
            "How many sons did Dhritarashtra and Gandhari have ?",12,"100","102","105",
            "110",1
        )
        que.add(q12)

        var q13=QuestionData(
            "Who was the eldest brother in Pandavas ?",13,"Yudhisthira","Bhima",
            "Arjuna","Nakula",1
        )
        que.add(q13)

        var q14=QuestionData(
            "Who was the eldest brother in Kauravas ?",14,"Vikarna","Dushashana",
            "Jalagandha","Duryodhana",4
        )
        que.add(q14)

        var q15=QuestionData(
            "What was the name of son of Princess Kunti and the sun god Surya ?",15,"Arjuna",
            "Bhima","Karna","Sahadeva",3
        )
        que.add(q15)

        var q16=QuestionData(
            "Who was the guru of Kauravas and Pandavas ?",16,"Dronacharya","Parashurama",
            "Ved Vyasa","Rishi Sage",1
        )
        que.add(q16)

        var q17=QuestionData(
            "What is the name of son of Dronacharya ?",17,"Jayadratha","Bhima","Ashwatthama",
            "Arjuna",3
        )
        que.add(q17)

        var q18=QuestionData(
            "Who was the brother of Gandhari and the maternal uncle of the Kauravas ?",18,"Shalya",
            "Shakuni","Drupada","None of These",2
        )
        que.add(q18)

        var q19=QuestionData(
            "Draupadi,heroic princess of Mahabharata,the daughter of King Drupada of Panchal,was married to ?",
            19,"Karna","Pandavas","Kauravas","Ashwatthama",2
        )
        que.add(q19)

        var q20=QuestionData(
            "What was the name of new kingdom built by Pandavas ?",20,"Hastinapur",
            "Panchal","Indraprastha","Gandhar",3
        )
        que.add(q20)

        var q21=QuestionData(
            "Where did the battle of Mahabharata take place ?",21,"Panipat","Kurukshetra",
            "Panchal","Hastinapur",2
        )
        que.add(q21)

        var q22=QuestionData(
            "Who were killed on 1st day of Mahabharata war ?",22,"Uttar and Sweta",
            "Abhimanyu and Karna","Shakuni and Dushashana","None of These",1
        )
        que.add(q22)

        var q23=QuestionData(
            "Jayadratha was a son-in-law of ?",23,"Pandu","Sanjay","Dronacharaya",
            "Dhritarashtra",4
        )
        que.add(q23)

        var q24=QuestionData(
            "Subhadra,sister of Krishna and Balrama was married to ?",24,"Karna","Duryodhana",
            "Arjuna","Sahadeva",3
        )
        que.add(q24)

        var q25=QuestionData(
            "Subhadra,sister of Krishna and Balrama was married to ?",25,"Sanjay","Vidur",
            "Daruka","Bhishma",1
        )
        que.add(q25)

        var q26=QuestionData(
            "Abhimanyu,the son of Subhadra and Arjuna,was killed while trying to break into a vyuha.Which vyuha was it ?",
            26,"Makarvyuha","Chakarvyuha","Sakatavyuha","Sukhimukhavyuha",2
        )
        que.add(q26)

        
        return que


    }
}